/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogomemoria;

import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author joaov
 */
public class JogoMemoria {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    Interface i = new Interface();
    i.setVisible(true);
    
    
           java.util.List<Coordenad> lista = new ArrayList();
        lista.add(new Coordenad(35, 19));
        lista.add(new Coordenad(165, 19));
        lista.add(new Coordenad(295, 19));
        lista.add(new Coordenad(425, 19));
        lista.add(new Coordenad(555, 19));
        lista.add(new Coordenad(686, 19));

        lista.add(new Coordenad(35, 149));
        lista.add(new Coordenad(165, 149));
        lista.add(new Coordenad(295, 149));
        lista.add(new Coordenad(425, 149));
        lista.add(new Coordenad(555, 149));
        lista.add(new Coordenad(686, 149));
        Collections.shuffle(lista);

        System.out.println(lista(0));

    
    }
    
}
