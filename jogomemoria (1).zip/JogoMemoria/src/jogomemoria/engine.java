/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogomemoria;

import javax.swing.JButton;

/**
 *
 * @author Guilherme
 */
public class engine extends Interface {
       private void Desvirar() {
    if(v>0){
    System.out.println("Funciona caraleo");
    }
}
}
