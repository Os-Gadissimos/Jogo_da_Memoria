/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogomemoria;

/**
 *
 * @author joaov
 */
public class Carta {
    
   public boolean reveladas;
   public double posicao;
   public int imagem;
  
   
   
}
