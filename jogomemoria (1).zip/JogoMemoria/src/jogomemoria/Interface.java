/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogomemoria;

import java.awt.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

/**
 *
 * @author joaov
 */
public class Interface extends javax.swing.JFrame {

    /**
     * Creates new form Interface
     */
    public Interface() {
        initComponents();
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Interface.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Interface.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Interface.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Interface.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.util.List<Coordenad> lista = new ArrayList();
        lista.add(new Coordenad(35, 19));
        lista.add(new Coordenad(165, 19));
        lista.add(new Coordenad(295, 19));
        lista.add(new Coordenad(425, 19));
        lista.add(new Coordenad(555, 19));
        lista.add(new Coordenad(686, 19));

        lista.add(new Coordenad(35, 149));
        lista.add(new Coordenad(165, 149));
        lista.add(new Coordenad(295, 149));
        lista.add(new Coordenad(425, 149));
        lista.add(new Coordenad(555, 149));
        lista.add(new Coordenad(686, 149));
        Collections.shuffle(lista);

        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(lista.get(0).x, lista.get(0).y, 112, 112));
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(lista.get(1).x, lista.get(1).y, 112, 112));
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(lista.get(2).x, lista.get(2).y, 112, 112));
        getContentPane().add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(lista.get(3).x, lista.get(3).y, 112, 112));
        getContentPane().add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(lista.get(4).x, lista.get(4).y, 112, 112));
        getContentPane().add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(lista.get(5).x, lista.get(5).y, 112, 112));
        getContentPane().add(jButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(lista.get(6).x, lista.get(6).y, 112, 112));
        getContentPane().add(jButton8, new org.netbeans.lib.awtextra.AbsoluteConstraints(lista.get(7).x, lista.get(7).y, 112, 112));
        getContentPane().add(jButton9, new org.netbeans.lib.awtextra.AbsoluteConstraints(lista.get(8).x, lista.get(8).y, 112, 112));
        getContentPane().add(jButton10, new org.netbeans.lib.awtextra.AbsoluteConstraints(lista.get(9).x, lista.get(9).y, 112, 112));
        getContentPane().add(jButton11, new org.netbeans.lib.awtextra.AbsoluteConstraints(lista.get(10).x, lista.get(10).y, 112, 112));
        getContentPane().add(jButton12, new org.netbeans.lib.awtextra.AbsoluteConstraints(lista.get(11).x, lista.get(11).y, 112, 112));

        if (po1) {

            pontos++;

        }
        if (po2) {

            pontos++;

        }
        if (po3) {

            pontos++;

        }
        if (po4) {

            pontos++;

        }
        if (po5) {

            pontos++;

        }
        if (po6) {

            pontos++;

        }
        
        jTextField1.setText("Seus pontos são: " + pontos);
        System.out.println(v);
        if (pontos >= 6) {
            pontos = 6;
        }
    }

    private JButton getjButton11() {
        return jButton11;
    }

    private void setjButton11(JButton jButton11) {
        this.jButton11 = jButton11;
    }

    public JButton getjButton12() {
        return jButton12;
    }

    public void setjButton12(JButton jButton12) {
        this.jButton12 = jButton12;
    }

    public JButton getjButton2() {
        return jButton2;
    }

    public void setjButton2(JButton jButton2) {
        this.jButton2 = jButton2;
    }

    public JButton getjButton3() {
        return jButton3;
    }

    public void setjButton3(JButton jButton3) {
        this.jButton3 = jButton3;
    }

    public JButton getjButton4() {
        return jButton4;
    }

    public void setjButton4(JButton jButton4) {
        this.jButton4 = jButton4;
    }

    public JButton getjButton5() {
        return jButton5;
    }

    public void setjButton5(JButton jButton5) {
        this.jButton5 = jButton5;
    }

    public JButton getjButton6() {
        return jButton6;
    }

    public void setjButton6(JButton jButton6) {
        this.jButton6 = jButton6;
    }

    public JButton getjButton7() {
        return jButton7;
    }

    public void setjButton7(JButton jButton7) {
        this.jButton7 = jButton7;
    }

    public JButton getjButton8() {
        return jButton8;
    }

    public void setjButton8(JButton jButton8) {
        this.jButton8 = jButton8;
    }

    public int getV() {
        return v;
    }

    public void setV(int v) {
        this.v = v;
    }

    public JButton getjButton9() {
        return jButton9;
    }

    public void setjButton9(JButton jButton9) {
        this.jButton9 = jButton9;
    }

    public JLabel getjLabel1() {
        return jLabel1;
    }

    public void setjLabel1(JLabel jLabel1) {
        this.jLabel1 = jLabel1;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/M.png"))); // NOI18N
        jButton1.setText("jButton1");
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
        });
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(35, 19, 112, 112));

        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/M.png"))); // NOI18N
        jButton2.setText("jButton2");
        jButton2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton2MouseClicked(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(165, 19, 112, 112));

        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/M.png"))); // NOI18N
        jButton3.setText("jButton3");
        jButton3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton3MouseClicked(evt);
            }
        });
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(295, 19, 112, 112));

        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/M.png"))); // NOI18N
        jButton4.setText("jButton4");
        jButton4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton4MouseClicked(evt);
            }
        });
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(425, 19, 112, 112));

        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/M.png"))); // NOI18N
        jButton5.setText("jButton5");
        jButton5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton5MouseClicked(evt);
            }
        });
        getContentPane().add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(555, 19, 113, 112));

        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/M.png"))); // NOI18N
        jButton6.setText("jButton6");
        jButton6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton6MouseClicked(evt);
            }
        });
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(686, 19, 111, 112));

        jButton7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/M.png"))); // NOI18N
        jButton7.setText("jButton7");
        jButton7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton7MouseClicked(evt);
            }
        });
        getContentPane().add(jButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(35, 149, 112, 112));

        jButton8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/M.png"))); // NOI18N
        jButton8.setText("jButton8");
        jButton8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton8MouseClicked(evt);
            }
        });
        getContentPane().add(jButton8, new org.netbeans.lib.awtextra.AbsoluteConstraints(165, 149, 113, 112));

        jButton9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/M.png"))); // NOI18N
        jButton9.setText("jButton9");
        jButton9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton9MouseClicked(evt);
            }
        });
        getContentPane().add(jButton9, new org.netbeans.lib.awtextra.AbsoluteConstraints(296, 149, 111, 112));

        jButton10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/M.png"))); // NOI18N
        jButton10.setText("jButton10");
        jButton10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton10MouseClicked(evt);
            }
        });
        getContentPane().add(jButton10, new org.netbeans.lib.awtextra.AbsoluteConstraints(425, 149, 112, 112));

        jButton11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/M.png"))); // NOI18N
        jButton11.setText("jButton11");
        jButton11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton11MouseClicked(evt);
            }
        });
        getContentPane().add(jButton11, new org.netbeans.lib.awtextra.AbsoluteConstraints(555, 149, 113, 112));

        jButton12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/M.png"))); // NOI18N
        jButton12.setText("jButton12");
        jButton12.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton12MouseClicked(evt);
            }
        });
        getContentPane().add(jButton12, new org.netbeans.lib.awtextra.AbsoluteConstraints(686, 149, 111, 112));

        jTextField1.setEditable(false);
        jTextField1.setBackground(new java.awt.Color(153, 153, 153));
        jTextField1.setText("jTextField1");
        getContentPane().add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 320, 130, 90));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/jogomemoria/memoria.png"))); // NOI18N
        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(-70, 0, 920, 470));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed

    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed


    }//GEN-LAST:event_jButton6ActionPerformed

    int pontos = 0;

    boolean p1 = true;
    boolean p2 = true;
    boolean p3 = true;
    boolean p4 = true;
    boolean p5 = true;
    boolean p6 = true;

    int v = 0;

    boolean po1 = false;
    boolean po2 = false;
    boolean po3 = false;
    boolean po4 = false;
    boolean po5 = false;
    boolean po6 = false;

    boolean clicado1 = false;
    boolean clicado2 = false;
    boolean clicado3 = false;
    boolean clicado4 = false;
    boolean clicado5 = false;
    boolean clicado6 = false;
    boolean clicado7 = false;
    boolean clicado8 = false;
    boolean clicado9 = false;
    boolean clicado10 = false;
    boolean clicado11 = false;
    boolean clicado12 = false;


    
    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseClicked
        if (v < 2) {
            if (clicado1 == false && p1) {
                if (clicado1 == false | clicado11 == false) {

                    jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("brabo.png")));
                    clicado1 = true;
                    v++;

                    if (clicado1 & clicado11) {

                         v=v-2;
                        p1 = true;
                        po1 = true;
                        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("brabo.png")));
                        jButton11.setIcon(new javax.swing.ImageIcon(getClass().getResource("brabo.png")));
                        clicado11 = false;
                        clicado1 = false;
                        jButton11.setEnabled(false);
                        jButton1.setEnabled(false);

                        if (po1) {
                            pontos++;
                            jTextField1.setText("Seus pontos são: " + pontos);
                        }
                    }
                }
            } else {
                if (clicado1 && clicado11 == false) {
                    jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("M.png")));
                    clicado1 = false;
                    v--;
                }
            }
        } else {
            if (clicado1 && clicado11 == false) {
                jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("M.png")));
                clicado1 = false;
                v--;
            }
    }//GEN-LAST:event_jButton1MouseClicked
    }
    private void jButton2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton2MouseClicked
        if (v < 2) {
            if (clicado2 == false && p2) {

                if (clicado2 == false | clicado8 == false) {
                    jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("triste.png")));
                    clicado2 = true;
                    v++;
                    if (clicado2 & clicado8) {
                        v=v-2;
                        po2 = true;
                        p2 = true;
                        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("triste.png")));
                        jButton8.setIcon(new javax.swing.ImageIcon(getClass().getResource("triste.png")));
                        clicado2 = false;
                        clicado8 = false;
                        jButton2.setEnabled(false);
                        jButton8.setEnabled(false);
                        if (po2) {
                            pontos++;
                            jTextField1.setText("Seus pontos são: " + pontos);
                        }

                    }
                }
            } else {
                if (clicado2 && clicado8 == false) {
                    jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("M.png")));
                    clicado2 = false;
                    v--;
                }

            }
        } else {
            if (clicado2 && clicado8 == false) {
                jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("M.png")));
                clicado2 = false;
                v--;
            }

        }
    }//GEN-LAST:event_jButton2MouseClicked

    private void jButton3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton3MouseClicked
        if (v < 2) {
            if (clicado3 == false && p3) {
                if (clicado3 == false | clicado4 == false) {
                    jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("maluco.png")));
                    clicado3 = true;
                    v++;
                    if (clicado3 & clicado4) {
                        v=v-2;
                        po3 = true;
                        p3 = true;
                        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("maluco.png")));
                        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("maluco.png")));
                        clicado3 = false;
                        clicado4 = false;
                        jButton3.setEnabled(false);
                        jButton4.setEnabled(false);
                        if (po3) {
                            pontos++;
                            jTextField1.setText("Seus pontos são: " + pontos);
                        }
                    }
                }
            } else {
                if (clicado3 && clicado4 == false) {
                    jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("M.png")));
                    clicado3 = false;
                    v--;
                }

            }

        } else {
            if (clicado3 && clicado4 == false) {
                jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("M.png")));
                clicado3 = false;
                v--;
            }

        }
    }//GEN-LAST:event_jButton3MouseClicked

    private void jButton4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton4MouseClicked
        if (v < 2) {
        if (clicado4 == false && p3) {
            if (clicado4 == false | clicado3 == false) {
                jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("maluco.png")));
                clicado4 = true;
                v++;
                if (clicado3 & clicado4) {
                     v=v-2;
                    po3 = true;
                    p3 = true;
                    jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("maluco.png")));
                    jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("maluco.png")));
                    clicado3 = false;
                    clicado4 = false;
                    jButton3.setEnabled(false);
                    jButton4.setEnabled(false);
                    if (po3) {
                        pontos++;
                        jTextField1.setText("Seus pontos são: " + pontos);
                    }

                }
            }
        } else {
            if (clicado4 && clicado3 == false) {
                jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("M.png")));
                clicado4 = false;
                v--;
            }

        }
 } else {
            if (clicado4 && clicado3 == false) {
                jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("M.png")));
                clicado4 = false;
                v--;
            }

        }

    }//GEN-LAST:event_jButton4MouseClicked

    private void jButton5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton5MouseClicked
          if (v < 2) {
        if (clicado5 == false && p5) {
            if (clicado5 == false | clicado9 == false) {
                jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("maravilhoso.png")));
                clicado5 = true;
                v++;
                if (clicado9 & clicado5) {
                 v=v-2;
                    po5 = true;
                    p5 = true;
                    jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("maravilhoso.png")));
                    jButton9.setIcon(new javax.swing.ImageIcon(getClass().getResource("maravilhoso.png")));
                    clicado5 = false;
                    clicado9 = false;
                    jButton5.setEnabled(false);
                    jButton9.setEnabled(false);
                    if (po5) {
                        pontos++;
                        jTextField1.setText("Seus pontos são: " + pontos);
                    }

                }
            }
        } else {
            if (clicado5 && clicado9 == false) {
                jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("M.png")));
                clicado5 = false;
                v--;
            }

        }
  } else {
            if (clicado5 && clicado9 == false) {
                jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("M.png")));
                clicado5 = false;
                v--;
            }

        }
    }//GEN-LAST:event_jButton5MouseClicked

    private void jButton6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton6MouseClicked
       if (v < 2) {
        if (clicado6 == false && p4) {
            if (clicado6 == false | clicado10 == false) {
                jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("entediado.png")));
                clicado6 = true;
                v++;
                if (clicado6 & clicado10) {
                   v=v-2;
                    po4 = true;
                    p4 = true;
                    jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("entediado.png")));
                    jButton10.setIcon(new javax.swing.ImageIcon(getClass().getResource("entediado.png")));
                    clicado6 = false;
                    clicado10 = false;
                    jButton10.setEnabled(false);
                    jButton6.setEnabled(false);
                    if (po4) {
                        pontos++;
                        jTextField1.setText("Seus pontos são: " + pontos);
                    }
                }
            }
        } else {
            if (clicado6 && clicado10 == false) {
                jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("M.png")));

                clicado6 = false;
                v--;
            }
        }
} else {
            if (clicado6 && clicado10 == false) {
                jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("M.png")));

                clicado6 = false;
                v--;
            }
        }
    }//GEN-LAST:event_jButton6MouseClicked

    private void jButton7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton7MouseClicked
       if (v < 2) {
        if (clicado7 == false && p6) {
            if (clicado7 == false | clicado12 == false) {
                jButton7.setIcon(new javax.swing.ImageIcon(getClass().getResource("feliz.png")));
                clicado7 = true;
                v++;
                if (clicado7 & clicado12) {
                    v=v-2;
                    po6 = true;
                    p6 = true;
                    jButton7.setIcon(new javax.swing.ImageIcon(getClass().getResource("feliz.png")));
                    jButton12.setIcon(new javax.swing.ImageIcon(getClass().getResource("feliz.png")));
                    clicado12 = false;
                    clicado7 = false;
                    jButton12.setEnabled(false);
                    jButton7.setEnabled(false);
                    if (po6) {
                        pontos++;
                        jTextField1.setText("Seus pontos são: " + pontos);
                    }

                }
            }
        } else {
            if (clicado7 && clicado12 == false) {
                jButton7.setIcon(new javax.swing.ImageIcon(getClass().getResource("M.png")));
                clicado7 = false;
                v--;
            }

        }
         } else {
            if (clicado7 && clicado12 == false) {
                jButton7.setIcon(new javax.swing.ImageIcon(getClass().getResource("M.png")));
                clicado7 = false;
                v--;
            }

        }
    }//GEN-LAST:event_jButton7MouseClicked

    private void jButton8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton8MouseClicked
         if (v < 2) {
        if (clicado8 == false && p2) {

            if (clicado2 == false | clicado8 == false) {
                jButton8.setIcon(new javax.swing.ImageIcon(getClass().getResource("triste.png")));
                clicado8 = true;
                v++;

                if (clicado2 & clicado8) {
                     v=v-2;
                    po2 = true;
                    p2 = true;
                    jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("triste.png")));
                    jButton8.setIcon(new javax.swing.ImageIcon(getClass().getResource("triste.png")));
                    clicado2 = false;
                    clicado8 = false;
                    jButton2.setEnabled(false);
                    jButton8.setEnabled(false);
                    if (po2) {
                        pontos++;
                        jTextField1.setText("Seus pontos são: " + pontos);
                    }

                }
            }
        } else {
            if (clicado8 && clicado2 == false) {
                jButton8.setIcon(new javax.swing.ImageIcon(getClass().getResource("M.png")));
                clicado8 = false;
                v--;
            }

        }
         } else {
            if (clicado8 && clicado2 == false) {
                jButton8.setIcon(new javax.swing.ImageIcon(getClass().getResource("M.png")));
                clicado8 = false;
                v--;
            }

        }
    }//GEN-LAST:event_jButton8MouseClicked

    private void jButton9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton9MouseClicked
       if (v < 2) {
        if (clicado9 == false && p5) {
            if (clicado5 == false | clicado9 == false) {
                jButton9.setIcon(new javax.swing.ImageIcon(getClass().getResource("maravilhoso.png")));
                clicado9 = true;
                v++;
                if (clicado9 & clicado5) {
                   v=v-2;
                    po5 = true;
                    p5 = true;
                    jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("maravilhoso.png")));
                    jButton9.setIcon(new javax.swing.ImageIcon(getClass().getResource("maravilhoso.png")));
                    clicado5 = false;
                    clicado9 = false;
                    jButton9.setEnabled(false);
                    jButton5.setEnabled(false);
                    if (po5) {
                        pontos++;
                        jTextField1.setText("Seus pontos são: " + pontos);
                    }
                }
            }
        } else {
            if (clicado9 && clicado5 == false) {
                jButton9.setIcon(new javax.swing.ImageIcon(getClass().getResource("M.png")));
                clicado9 = false;
                v--;
            }

        }
         } else {
            if (clicado9 && clicado9 == false) {
                jButton9.setIcon(new javax.swing.ImageIcon(getClass().getResource("M.png")));
                clicado9 = false;
                v--;
            }

        }
    }//GEN-LAST:event_jButton9MouseClicked

    private void jButton10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton10MouseClicked
         if (v < 2) {
        if (clicado10 == false && p4) {
            if (clicado6 == false | clicado10 == false) {
                jButton10.setIcon(new javax.swing.ImageIcon(getClass().getResource("entediado.png")));
                clicado10 = true;
                v++;
                if (clicado6 & clicado10) {
                     v=v-2;
                    po4 = true;
                    p4 = true;
                    jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("entediado.png")));
                    jButton10.setIcon(new javax.swing.ImageIcon(getClass().getResource("entediado.png")));
                    clicado6 = false;
                    clicado10 = false;
                    jButton10.setEnabled(false);
                    jButton6.setEnabled(false);
                    if (po4) {
                        pontos++;
                        jTextField1.setText("Seus pontos são: " + pontos);
                    }
                }
            }

        } else {
            if (clicado10 && clicado6 == false) {
                jButton10.setIcon(new javax.swing.ImageIcon(getClass().getResource("M.png")));
                clicado10 = false;
                v--;
            }

        }
        } else {
            if (clicado10 && clicado6 == false) {
                jButton10.setIcon(new javax.swing.ImageIcon(getClass().getResource("M.png")));
                clicado10 = false;
                v--;
            }

        }
    }//GEN-LAST:event_jButton10MouseClicked

    private void jButton11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton11MouseClicked
        if (v < 2) {
        if (clicado11 == false && p1) {

            if (clicado1 == false | clicado11 == false) {

                jButton11.setIcon(new javax.swing.ImageIcon(getClass().getResource("brabo.png")));
                clicado11 = true;
                v++;

                if (clicado1 & clicado11) {
                 v=v-2;
                    p1 = true;
                    po1 = true;

                    jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("brabo.png")));
                    jButton11.setIcon(new javax.swing.ImageIcon(getClass().getResource("brabo.png")));
                    clicado11 = false;
                    clicado1 = false;
                    jButton11.setEnabled(false);
                    jButton1.setEnabled(false);
                    if (po1) {
                        pontos++;
                        jTextField1.setText("Seus pontos são: " + pontos);
                    }

                }
            }
        } else {
            if (clicado11 && clicado1 == false) {
                jButton11.setIcon(new javax.swing.ImageIcon(getClass().getResource("M.png")));
                clicado11 = false;
                v--;
            }
        }
 } else {
            if (clicado11 && clicado1 == false) {
                jButton11.setIcon(new javax.swing.ImageIcon(getClass().getResource("M.png")));
                clicado11 = false;
                v--;
            }
        }

    }//GEN-LAST:event_jButton11MouseClicked

    private void jButton12MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton12MouseClicked
        if (v < 2) {
        if (clicado12 == false && p6) {
            if (clicado7 == false | clicado12 == false) {
                jButton12.setIcon(new javax.swing.ImageIcon(getClass().getResource("feliz.png")));
                clicado12 = true;
                v++;
                if (clicado7 & clicado12) {
                     v=v-2;
                    po6 = true;
                    p6 = true;
                    jButton7.setIcon(new javax.swing.ImageIcon(getClass().getResource("feliz.png")));
                    jButton12.setIcon(new javax.swing.ImageIcon(getClass().getResource("feliz.png")));
                    clicado12 = false;
                    clicado7 = false;
                    jButton12.setEnabled(false);
                    jButton7.setEnabled(false);
                    if (po6) {
                        pontos++;
                        jTextField1.setText("Seus pontos são: " + pontos);
                    }
                }
            }
        } else {
            if (clicado12 && clicado7 == false) {
                jButton12.setIcon(new javax.swing.ImageIcon(getClass().getResource("M.png")));
                clicado12 = false;
                v--;
            }
        }
 } else {
            if (clicado12 && clicado7 == false) {
                jButton12.setIcon(new javax.swing.ImageIcon(getClass().getResource("M.png")));
                clicado12 = false;
                v--;
            }
        }
    }//GEN-LAST:event_jButton12MouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {

    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables
}
